package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Application {

	public static void main(String[] args) throws InterruptedException {

		SessionFactory sf = HibernateUtil.getConnection();

		Session s = sf.openSession();

//		Employee emp = new Employee();
//		emp.setEid(5005);
//		emp.setEname("rahul");
//		emp.setEaddress("pcmc");

		Employee emp1 = s.get(Employee.class, 5005);
		System.out.println(emp1);

		s.evict(emp1);
		s.clear();

		Employee emp2 = s.get(Employee.class, 5005);
		System.out.println(emp2);

//		s.save(emp);

		s.beginTransaction().commit();
		System.out.println("success");

	}

}
