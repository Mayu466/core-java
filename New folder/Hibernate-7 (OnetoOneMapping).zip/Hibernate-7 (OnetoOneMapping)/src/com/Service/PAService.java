package com.Service;

public interface PAService {

	void addPersonWithAdhar();

	void getPersonOnly();

	void getAdharOnly();

	void updatePerson();

	void deletePerson();

	void deletePersonOnly();
}
