package com.Controller;

import com.Service.PAService;
import com.ServiceIMPL.ServiceIMPL;

public class HomeController {

	public static void main(String[] args) {

		PAService ps = new ServiceIMPL();

//		ps.addPersonWithAdhar();

//		ps.getPersonOnly();

//		ps.getAdharOnly();

//		ps.deletePerson();

		ps.deletePersonOnly();
	}
}
