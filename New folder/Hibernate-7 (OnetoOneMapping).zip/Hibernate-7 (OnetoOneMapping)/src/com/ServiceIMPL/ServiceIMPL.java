package com.ServiceIMPL;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.Entity.Adhar;
import com.Entity.Person;
import com.Service.PAService;
import com.Util.HibernateUtil;

public class ServiceIMPL implements PAService {

	SessionFactory sf = HibernateUtil.getConnection();

	@Override
	public void addPersonWithAdhar() {

		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();
		Person p = new Person();

		System.out.println("Enter the Person name :- ");
		p.setPname(sc.next());
		System.out.println("Enter the Person Address :- ");
		p.setPaddress(sc.next());

		Adhar ad = new Adhar();
		System.out.println("Enter the Adhar Number :- ");
		ad.setAdharNumber(sc.nextLong());

		p.setAdhar(ad);

		s.save(p);
		s.beginTransaction().commit();
		System.out.println("success");

	}

	@Override
	public void getPersonOnly() {
		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();

		System.out.println("Enter the PersonID :- ");
		int id = sc.nextInt();
		Person p = s.get(Person.class, id);
		if (p != null) {
			System.out.println(p.getPid());
			System.out.println(p.getPname());
			System.out.println(p.getPaddress());
		} else {
			System.out.println("Id is Invalid!!!");
		}

	}

	@Override
	public void getAdharOnly() {

		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();

		System.out.println("Enter the PersonID :- ");
		int id = sc.nextInt();
		Person p = s.get(Person.class, id);
		if (p != null) {
			System.out.println(p.getAdhar());
		} else {
			System.out.println("Id is Invalid!!!");
		}

	}

	// addPersonToExistingAdhar()

	// deleteAdharOnly()

	@Override
	public void updatePerson() {
//
	}

	@Override
	public void deletePerson() {
		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();

		System.out.println("Enter the PersonID :- ");
		int id = sc.nextInt();
		Person p = s.get(Person.class, id);
		if (p != null) {

			s.delete(p);
			s.beginTransaction().commit();
			System.out.println("person has been delete!!!");

		} else {
			System.out.println("Id is Invalid!!!");
		}

	}

	@Override
	public void deletePersonOnly() {
		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();

		System.out.println("Enter the PersonID :- ");
		int id = sc.nextInt();
		Person p = s.get(Person.class, id);
		if (p != null) {

			// pid -> 2
			p.setAdhar(null);
			s.update(p);
			s.delete(p);
			s.beginTransaction().commit();
			System.out.println("successs");
		} else {
			System.out.println("Id is Invalid!!!");
		}

	}

}
