package com.classmng.model;

public class Faculty {
	
	private int fid;
	
	private String fanme;
	
	private Course course;//11 java

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public String getFanme() {
		return fanme;
	}

	public void setFanme(String fanme) {
		this.fanme = fanme;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	@Override
	public String toString() {
		return "Faculty [fid=" + fid + ", fanme=" + fanme + ", course=" + course + "]";
	}
	
	

}
