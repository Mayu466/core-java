package com.classmng.service;

public interface Services {

	void addCourse();

	void displayCourse();

	void addFaculty();

	void displayFaculty();

	void addBatch();

	void displayBatch();

	void addStudent();

	void displayStudent();

}
