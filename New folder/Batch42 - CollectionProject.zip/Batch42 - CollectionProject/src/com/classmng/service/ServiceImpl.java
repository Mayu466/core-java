package com.classmng.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.classmng.model.Batch;
import com.classmng.model.Course;
import com.classmng.model.Faculty;
import com.classmng.model.Student;

public class ServiceImpl  implements Services{
	
	Scanner sc=new Scanner(System.in);
	List<Course> clist= new ArrayList<Course>();
	List<Faculty> flist= new ArrayList<Faculty>();
	List<Batch> blist= new ArrayList<Batch>();
	List<Student> slist= new ArrayList<Student>();

	@Override
	public void addCourse() {
		
		System.out.println("How many courses u want to add : ");
		int n=sc.nextInt();
		
		for(int i=1;i<=n;i++) {
			
			Course c= new Course();
			System.out.println("Enter cid : ");
			c.setCid(sc.nextInt());
			
			System.out.println("enter cname : ");
			c.setCname(sc.next());
			
			clist.add(c);
		}
		
	}

	@Override
	public void displayCourse() {
		for(Course c:clist) {
			System.out.println(c);
		}
		
	}

	@Override
	public void addFaculty() {
		
		System.out.println("How many faculty u want to add : ");
		int n=sc.nextInt();
		
		for(int i=1;i<=n;i++) {
			Faculty faculty= new Faculty();
			
			System.out.println("Enter fid : ");
			faculty.setFid(sc.nextInt());
			
			System.out.println("Enter fname : ");
			faculty.setFanme(sc.next());
			
			System.out.println("Choose course from following");
			displayCourse();
			
			int cid=sc.nextInt();
			
			for(Course c:clist) {
				if(c.getCid()==cid) {
					faculty.setCourse(c);
				}
			}
			
			
			flist.add(faculty);
			
		}
		
	}

	@Override
	public void displayFaculty() {
		for(Faculty f:flist) {
			System.out.println(f);
		}
		
	}

	@Override
	public void addBatch() {
		System.out.println("how many batch u want to add : ");
		int n= sc.nextInt();
		
		for(int i=1;i<=n;i++) {
			
			Batch batch= new Batch();
			System.out.println("enter bid : ");
			batch.setBid(sc.nextInt());
			
			System.out.println("Enter bname : ");
			batch.setBname(sc.next());
			
			System.out.println("Choose faculty from followingm :");
			displayFaculty();
			
			int fid=sc.nextInt();
			
			for(Faculty f:flist) {
				if(f.getFid()==fid) {
					batch.setFaculty(f);
				}
			}
			
			blist.add(batch);
		}
		
	}

	@Override
	public void displayBatch() {
		
		for(Batch b:blist) {
			System.out.println(b);
		}
		
	}

	@Override
	public void addStudent() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayStudent() {
		// TODO Auto-generated method stub
		
	}

}
