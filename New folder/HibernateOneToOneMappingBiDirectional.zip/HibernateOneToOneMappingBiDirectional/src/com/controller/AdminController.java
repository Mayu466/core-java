package com.controller;

import com.service.ServiceImpl;
import com.service.ServiceInterface;

public class AdminController {

	public static void main(String[] args) {
		ServiceInterface si = new ServiceImpl();
		
		//si.addBankAccountWithUser();
		
		//si.getAccountWithUser();
		
		//si.deleteUserOnlyUsingBankId();
		
		si.addExistingAccountForExistingUser();
	}
}
