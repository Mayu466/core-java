package com.service;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.model.BankAccount;
import com.model.User;
import com.util.HibernateUtil;

public class ServiceImpl implements ServiceInterface{
	
	SessionFactory sf = HibernateUtil.getSessionFactory();

	@Override
	public void addBankAccountWithUser() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		
		BankAccount b = new BankAccount();
		System.out.println("Enter bankname:");
		b.setBankname(sc.next());
		System.out.println("Enter accno:");
		b.setAccno(sc.nextLong());
		
		User user = new User();
		System.out.println("Enter user name:");
		user.setUsername(sc.next());
		
		b.setUser(user);
		user.setBankacc(b);
		
		s.save(b);
		s.beginTransaction().commit();
		System.out.println("success");
		
	}

	@Override
	public void deleteUserOnlyUsingBankId() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter bank id:");
		
		BankAccount b = s.get(BankAccount.class, sc.nextInt());
		
		if (b!=null) {
			User user1= b.getUser();
			
			user1.setBankacc(null);
			b.setUser(null);
			
			s.update(user1);
			s.delete(user1);
			s.beginTransaction().commit();
			System.out.println("success");
		} else {
			System.out.println("account doesn't exist!!");
		}
		
	}

	@Override
	public void addExistingAccountForExistingUser() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter bank id:");
		
		BankAccount b = s.get(BankAccount.class, sc.nextInt());
		
		if (b!=null && b.getUser() == null) {
			
			System.out.println("Enter user id:");
			
			User user = s.get(User.class, sc.nextInt());
			
			if (user != null ) {
				b.setUser(user);
				s.update(b);
				s.beginTransaction().commit();
				System.out.println("success!");
				
			} else {
				System.out.println(" User doesn't exist");
			}
		}else {
			System.out.println("User not null");
		}
		
	}

	@Override
	public void updateAccountWithUser() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getAccountWithUser() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter bank id:");
		
		BankAccount b = s.get(BankAccount.class, sc.nextInt());
		
		if (b!=null) {
			System.out.println(b);
		} else {
			System.out.println("account doesn't exist!!");
		}
		
	}

	@Override
	public void getOnlyAccountByAccountId() {
		// TODO Auto-generated method stub
		
	}

}
