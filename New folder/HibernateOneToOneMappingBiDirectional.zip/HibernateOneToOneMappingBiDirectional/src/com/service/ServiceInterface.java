package com.service;

public interface ServiceInterface {
	
	public void addBankAccountWithUser();
	
	public void deleteUserOnlyUsingBankId();
	
	public void addExistingAccountForExistingUser();
	
	public void updateAccountWithUser();
	
	public void getAccountWithUser();
	
	public void getOnlyAccountByAccountId();

}
