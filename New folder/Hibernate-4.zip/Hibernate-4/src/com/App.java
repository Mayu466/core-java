package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class App {

	public static void main(String[] args) {

		SessionFactory sf = HibernateUtil.getConnection();

		Session s = sf.openSession();

// insert into Employee (ename, eid) values (?, ?)

		Employee e = new Employee();
		e.setEid(2);
		e.setEname("rahil");
		e.setEaddress("pune");

//		s.save(e);
		s.saveOrUpdate(e);
		s.beginTransaction().commit();
		System.out.println("success");

	}
}
