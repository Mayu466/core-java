package com.controller;

import com.service.BankServirce;
import com.service.BankServirceImpl;

public class AdminController {
	
	public static void main(String[] args) {
		
		BankServirce bs = new BankServirceImpl();
		
		//bs.addBankAccountUser();
		
		//bs.deleteBankAccountUser();
		
		bs.updateBankAccount();
	}

}
