package com.service;

public interface BankServirce {
	
	public void addBankAccountUser();
	
	public void getBankAccount();
	
	public void getUserOnly();
	
	public void updateBankAccount();
	
	public void deleteBankAccountUser();
	
	public void addExistingBankAccountWithExistingUser();
	
	
	

}
