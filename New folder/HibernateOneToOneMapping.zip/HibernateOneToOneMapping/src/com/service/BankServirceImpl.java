package com.service;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.sbi.BankAccount;
import com.sbi.User;
import com.util.HibernateUtil;

public class BankServirceImpl implements BankServirce{
	SessionFactory sf = HibernateUtil.getSessionFactory();
	
	@Override
	public void addBankAccountUser() {
		Session session = sf.openSession();
		
		Scanner sc = new Scanner(System.in);
		
		BankAccount b = new BankAccount();
		
		System.out.println("Enter acc no:");
		b.setAccno(sc.nextLong());
		
		System.out.println("Enter bank name:");
		b.setBankname(sc.next());
		
		User user = new User();
		System.out.println("Enter user name:");
		user.setUsername(sc.next());
		
		b.setUser(user);
		
		session.save(b);
		
		session.beginTransaction().commit();
		
		System.out.println("Success!!");
	}

	@Override
	public void getBankAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getUserOnly() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBankAccount() {
		Session s = sf.openSession();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter bank id:");
		
		BankAccount ba = s.get(BankAccount.class, sc.nextInt());
		
		if (ba !=null) {
			System.out.println("Enter bank name:");
			String bname = sc.next();
			ba.setBankname(bname);
			System.out.println("enter user id");
			User u = s.get(User.class, sc.nextInt());
			if (u != null) {
				System.out.println("Enter user name:");
				String uname = sc.next();
				u.setUsername(uname);
			} else {
				System.out.println("account details doesn't exist!!");
			}
			ba.setUser(u);
		} else {
			System.out.println("account details doesn't exist!!");
		}
		s.update(ba);
		s.beginTransaction().commit();
		
	}

	@Override
	public void deleteBankAccountUser() {
		Session s = sf.openSession();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter bank id:");
		
		BankAccount ba = s.get(BankAccount.class, sc.nextInt());
		
		if (ba !=null) {
			s.delete(ba);
		} else {
			System.out.println("account details doesn't exist!!");
		}
		s.beginTransaction().commit();
	}

	@Override
	public void addExistingBankAccountWithExistingUser() {
		// TODO Auto-generated method stub
		
	}

}
