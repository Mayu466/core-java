package com.exponent;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Application {

	public static void main(String[] args) {

		Employee emp1 = new Employee();
		emp1.setEid(101);
		emp1.setEname("rahul");
		emp1.setEaddress("pune");
		emp1.setEsalary(550000.0);

		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");

		SessionFactory sf = cfg.buildSessionFactory();

		Session s = sf.openSession();

		s.save(emp1);
		s.beginTransaction().commit();
		System.out.println("Sucessfully employee inserted!!!");

	}
}
