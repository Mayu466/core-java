package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Application {

	public static void main(String[] args) {

		SessionFactory sf = HibernateUtil.getConnection();

		Session s = sf.openSession();

		Student stu = new Student();
//		stu.setSid(104);
		stu.setSname("jhon");
		stu.setSaddress("pune");

		s.save(stu);

		s.beginTransaction().commit();
		System.out.println("sucess");

	}
}
