package com.Exponent;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class App {

	public static void main(String[] args) {

		SessionFactory sf = HibernateUtil.getConnection();

		Session s = sf.openSession();

//		School s1 = new School();

//		s1.setSchoolId(3);
//		s1.setSchoolName("pqr");
//		s1.setUnivertisyName("pune");

//		s.save(s1);
//		s.saveOrUpdate(s1);
//		s.update(s1);
//		s.delete(s1);

//		School school3 = s.get(School.class, 1001);
		School school3 = s.load(School.class, 1001);
//		System.out.println(school3);

		System.out.println(school3.getSchoolId());
		System.out.println(school3.getSchoolName());
		System.out.println(school3.getUnivertisyName());

		s.beginTransaction().commit();
		System.out.println("success");

	}
}
