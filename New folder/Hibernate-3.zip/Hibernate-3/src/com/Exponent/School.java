package com.Exponent;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class School {

	@Id
	private int schoolId;

	private String schoolName;

	private String univertisyName;

	public int getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getUnivertisyName() {
		return univertisyName;
	}

	public void setUnivertisyName(String univertisyName) {
		this.univertisyName = univertisyName;
	}

	@Override
	public String toString() {
		return "School [schoolId=" + schoolId + ", schoolName=" + schoolName + ", univertisyName=" + univertisyName
				+ "]";
	}

}
