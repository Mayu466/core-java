package com.Service;

public interface PAService {

	public void addPersonWithAdhar();

	public void getPersonOnly();

	public void getAdharOnly();

	public void deletePersonwithAdharUsingPid();

	public void deletePersonOnlyUsingPid();

	public void deteleAdharOnlyUsingPid();

	public void deletePersonOnlyUsingAid();

	public void deleteAdharOnlyUsingAid();

}
