package com.Controller;

import com.Service.PAService;
import com.ServiceIMPL.ServiceImplementaion;

public class HomeController {

	public static void main(String[] args) {

		PAService ps = new ServiceImplementaion();

//		ps.addPersonWithAdhar();

//		ps.deletePersonwithAdharUsingPid();

//		ps.deletePersonOnlyUsingPid();

//		ps.deletePersonOnlyUsingAid();

//		ps.deleteAdharOnlyUsingAid();

	}
}
