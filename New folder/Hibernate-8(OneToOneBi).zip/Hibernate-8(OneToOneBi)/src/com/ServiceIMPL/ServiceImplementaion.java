package com.ServiceIMPL;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.Entity.Adhar;
import com.Entity.Person;
import com.Service.PAService;
import com.Util.HibernateUtil;

public class ServiceImplementaion implements PAService {

	SessionFactory sf = HibernateUtil.getConnection();

	@Override
	public void addPersonWithAdhar() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		Person p = new Person();
		System.out.println("Enter the Person Name :- ");
		p.setPname(sc.next());

		System.out.println("Enter the Person Address :- ");
		p.setPaddress(sc.next());

		Adhar ad = new Adhar();
		System.out.println("Enter the Adhar Number");
		ad.setAdharNumber(sc.nextLong());

		p.setAdhar(ad);
		ad.setPerson(p);

		s.save(p);
		s.beginTransaction().commit();
		System.out.println("success");

	}

	@Override
	public void getPersonOnly() {

	}

	@Override
	public void getAdharOnly() {
		// TODO Auto-generated method stub

	}

	
	//addExistingPersonToExistingAdhar
	//addPersonOnly
	//addAdharonly
	
	@Override
	public void deletePersonwithAdharUsingPid() {
		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();
		System.out.println("Enter the Pid :- ");
		int id = sc.nextInt();
		Person p = s.get(Person.class, id);
		if (p != null) {
			s.delete(p);
		} else {
			System.out.println("Invalid");
		}

		s.beginTransaction().commit();
		System.out.println("success");

	}

	@Override
	public void deletePersonOnlyUsingPid() {
		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();
		System.out.println("Enter the Pid :- ");
		Person p = s.get(Person.class, sc.nextInt());
		if (p != null) {
			Adhar ad = p.getAdhar();
			ad.setPerson(null);
			p.setAdhar(null);
			s.update(p);
			s.delete(p);
			s.beginTransaction().commit();
			System.out.println("Success");
		} else {
			System.out.println("Invalid ID");
		}

	}

	@Override
	public void deteleAdharOnlyUsingPid() {
		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();
		System.out.println("Enter the Pid :- ");
		Person p = s.get(Person.class, sc.nextInt());
		if (p != null) {
			Adhar ad = p.getAdhar();
			ad.setPerson(null);
			p.setAdhar(null);
			s.update(ad);
			s.delete(ad);
			s.beginTransaction().commit();
			System.out.println("Success");
		} else {
			System.out.println("Invalid ID");
		}

	}

	@Override
	public void deletePersonOnlyUsingAid() {
		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();
		System.out.println("Enter the Aid :- ");
		Adhar ad = s.get(Adhar.class, sc.nextInt());

		if (ad != null) {

			Person p = ad.getPerson();
			p.setAdhar(null);
			ad.setPerson(null);
			s.update(ad);
			s.delete(p);
			s.beginTransaction().commit();
			System.out.println("Success");

		} else {
			System.out.println("Invalid ID");
		}

	}

	@Override
	public void deleteAdharOnlyUsingAid() {
		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();
		System.out.println("Enter the Aid :- ");
		Adhar ad = s.get(Adhar.class, sc.nextInt());

		if (ad != null) {

			Person p = ad.getPerson();
			p.setAdhar(null);
			ad.setPerson(null);
			s.update(p);
			s.delete(ad);
			s.beginTransaction().commit();
			System.out.println("Success");

		} else {
			System.out.println("Invalid ID");
		}

	}

}
